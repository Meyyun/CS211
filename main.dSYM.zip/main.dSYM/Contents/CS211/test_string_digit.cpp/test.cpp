#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

// Function to add two numbers represented as strings
string addStrings(string num1, string num2) {
    string result = ""; 
    int carry = 0;

    int i = num1.length() - 1; // Start from the last digit
    int j = num2.length() - 1;

    while (i >= 0 || j >= 0 || carry) {
        int digit1 = (i >= 0) ? num1[i] - '0' : 0; // Convert character to integer
        int digit2 = (j >= 0) ? num2[j] - '0' : 0;

        int sum = digit1 + digit2 + carry;
        carry = sum / 10; // Carry for next iteration
        result += (sum % 10) + '0'; // Store the last digit of sum

        i--;
        j--;
    }

    reverse(result.begin(), result.end()); // Reverse to get the correct order
    return result;
}

int main() {
    string I = "899";
    string J = "551 ";

    string sum = addStrings(I, J);
    cout << "Sum: " << sum << endl; // Output: 246

    return 0;
}
