// Online C++ compiler to run C++ program online
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
class String_Calculate
{
    private:
        int len1;
        int sum;
        string result = "";
    public:
        int length(string num1,string num2)
        {
            if (num1.length()>num2.length())
            {
                len1 = num1.length();
            }
            else
            {
                len1 = num2.length();
            }
            return len1;
        }
        string sum2(string num1,string num2)
        {
            int carry = 0;
            for (int i=len1-1;i>=0;i--)
            {
                int num1_1 = num1[i] - '0';
                int num2_1 = num2[i] - '0';
                sum = num1_1+num2_1+carry;
                carry = sum/10;
                sum = sum%10;
                result += sum + '0';
            }
            reverse(result.begin(),result.end());
            return result;
        }
};
int main() {
    String_Calculate str;
    cout<<"Enter yor numbers:";
    string num1,num2;
    cin>>num1>>num2;
    str.length(num1,num2);
    cout<<"Sum : "<<str.sum2(num1,num2);
    
    return 0;
}